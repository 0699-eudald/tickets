<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Blok Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Wyświetla banner na górze sklepu.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Wystąpił błąd podczas próby przesłania pliku.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia zostały zaktualizowane.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Top banner obrazu';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Przesłać obraz do góry baner. Zalecane wymiary to 1170 x 65px jeśli używasz domyślnego motywu.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Odsyłacz';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Podaj link skojarzony z banerem. Po kliknięciu na banner, link otwiera się w tym samym oknie. Jeżeli żadne połączenie nie zostanie wprowadzony, to przekierowuje do strony głównej.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Opis Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Proszę wprowadzić krótki, ale znaczący opis sztandarem.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockbanner}leo_sportshoes>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Wybierz plik';
