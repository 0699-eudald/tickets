<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Blocco Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Consente di visualizzare un banner nella parte superiore del negozio.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Si è verificato un errore durante il tentativo di caricare il file.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono state aggiornate.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Immagine del banner Top';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Carica una foto per il vostro banner in alto. Le dimensioni consigliate sono 1170 x 65px se si utilizza il tema di default.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Link banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Inserire il link associato al vostro banner. Cliccando sul banner, il collegamento si apre nella stessa finestra. Se non viene inserito alcun collegamento, che reindirizza alla pagina iniziale.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Descrizione Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Si prega di inserire una breve ma significativa descrizione per il banner.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockbanner}leo_sportshoes>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Scegliere un file';
