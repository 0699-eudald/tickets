<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloc bannière';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Affiche une bannière en haut de la boutique.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'une erreur s\'est produite lors de l\'envoi';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Image Haut de la bannière';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Téléchargez une image pour votre top banner. Les dimensions recommandées sont 1170 x 65px si vous utilisez le thème par défaut.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Bannière Lien';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Entrez le lien associé à votre bannière. En cliquant sur la bannière, le lien ouvre dans la même fenêtre. Si aucun lien est entré, il redirige vers la page d\'accueil.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Description de la Bannière';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Veuillez saisir une description courte mais précise pour votre bannière.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockbanner}leo_sportshoes>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Choisissez un fichier';
