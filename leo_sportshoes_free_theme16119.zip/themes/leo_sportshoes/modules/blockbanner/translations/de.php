<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Block Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Zeigt ein Banner an der Spitze des Shops.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Hochladen der Datei';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen werden aktualisiert';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Top Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Laden Sie ein Bild für Ihre Top-Banner. Die empfohlenen Abmessungen 1170 x 65px, wenn Sie die Standard-Theme werden.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Link-Banner';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Geben Sie den Link, um Ihre Banner verbunden. Beim Klick auf den Banner öffnet sich der Link im selben Fenster. Wenn keine Verbindung eingegeben wird, leitet es automatisch auf die Homepage.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Banner Beschreibung';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Bitte geben Sie eine kurze, treffende Bescheibung für das Banner ein.';
$_MODULE['<{blockbanner}leo_sportshoes>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockbanner}leo_sportshoes>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Datei auswählen';
