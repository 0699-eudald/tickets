<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'Лучшие продавцы блок';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Добавляет блок отображения самых продаваемых продуктов вашего магазина.';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_26986c3388870d4148b1b5375368a83d'] = 'Продукты для отображения';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_2b21378492166b0e5a855e2da611659c'] = 'Определить количество продукта, чтобы отобразить в этом блоке';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Всегда показывать этот блок';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Показать блок, даже если не лучшие продавцы не доступны.';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Отключено';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'Нет лучших продавцов в это время.';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Просмотреть продукцию высшего продавцов';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Лучшие продавцы';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Все лучшие продавцы';
$_MODULE['<{blockbestsellers}leo_sportshoes>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Нет лучших продавцов в это время';
$_MODULE['<{blockbestsellers}leo_sportshoes>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Бестселлеры';
